package presentacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal {

	private static JFrame frmAgendaMonoltica;
	private JPanel panel;
	private JButton btnAadirContacto;
	private JButton btnEliminarContacto;
	private JButton btnBuscarContacto;
	private JButton btnModificarContacto;
	private AnadirUI anadirUI;
	private BorrarUI borrarUI;
	private ModificarUI modificarUI;
	private BuscarUI buscarUI;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.getFrmAgendaMonoltica().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setFrmAgendaMonoltica(new JFrame());
		getFrmAgendaMonoltica().setTitle("Agenda Monolítica");
		getFrmAgendaMonoltica().setBounds(100, 100, 361, 209);
		getFrmAgendaMonoltica().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		{
			panel = new JPanel();
			getFrmAgendaMonoltica().getContentPane().add(panel, BorderLayout.CENTER);
			GridBagLayout gbl_panel = new GridBagLayout();
			gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
			gbl_panel.rowHeights = new int[]{0, 50, 11, 50, 0, 0};
			gbl_panel.columnWeights = new double[]{1.0, 0.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
			gbl_panel.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
			panel.setLayout(gbl_panel);
			{
				btnAadirContacto = new JButton("Añadir Contacto");
				btnAadirContacto.addActionListener(new BtnAadirContactoActionListener());
				GridBagConstraints gbc_btnAadirContacto = new GridBagConstraints();
				gbc_btnAadirContacto.fill = GridBagConstraints.BOTH;
				gbc_btnAadirContacto.insets = new Insets(0, 0, 5, 5);
				gbc_btnAadirContacto.gridx = 1;
				gbc_btnAadirContacto.gridy = 1;
				panel.add(btnAadirContacto, gbc_btnAadirContacto);
			}
			{
				btnEliminarContacto = new JButton("Eliminar Contacto");
				btnEliminarContacto.addActionListener(new BtnEliminarContactoActionListener());
				GridBagConstraints gbc_btnEliminarContacto = new GridBagConstraints();
				gbc_btnEliminarContacto.fill = GridBagConstraints.BOTH;
				gbc_btnEliminarContacto.insets = new Insets(0, 0, 5, 5);
				gbc_btnEliminarContacto.gridx = 3;
				gbc_btnEliminarContacto.gridy = 1;
				panel.add(btnEliminarContacto, gbc_btnEliminarContacto);
			}
			{
				btnBuscarContacto = new JButton("Buscar Contacto");
				btnBuscarContacto.addActionListener(new BtnBuscarContactoActionListener());
				GridBagConstraints gbc_btnBuscarContacto = new GridBagConstraints();
				gbc_btnBuscarContacto.fill = GridBagConstraints.BOTH;
				gbc_btnBuscarContacto.insets = new Insets(0, 0, 5, 5);
				gbc_btnBuscarContacto.gridx = 1;
				gbc_btnBuscarContacto.gridy = 3;
				panel.add(btnBuscarContacto, gbc_btnBuscarContacto);
			}
			{
				btnModificarContacto = new JButton("Modificar Contacto");
				btnModificarContacto.addActionListener(new BtnModificarContactoActionListener());
				GridBagConstraints gbc_btnModificarContacto = new GridBagConstraints();
				gbc_btnModificarContacto.fill = GridBagConstraints.BOTH;
				gbc_btnModificarContacto.insets = new Insets(0, 0, 5, 5);
				gbc_btnModificarContacto.gridx = 3;
				gbc_btnModificarContacto.gridy = 3;
				panel.add(btnModificarContacto, gbc_btnModificarContacto);
			}
		}
	}

	public static JFrame getFrmAgendaMonoltica() {
		return frmAgendaMonoltica;
	}

	public static void setFrmAgendaMonoltica(JFrame frmAgendaMonoltica) {
		Principal.frmAgendaMonoltica = frmAgendaMonoltica;
	}

	private class BtnAadirContactoActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			getFrmAgendaMonoltica().setVisible(false);
			anadirUI = new AnadirUI();
			anadirUI.getFrmAgendaMonoltica().setVisible(true);
			
		}
	}
	private class BtnEliminarContactoActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			getFrmAgendaMonoltica().setVisible(false);
			borrarUI = new BorrarUI();
			borrarUI.getFrmAgendaMonoltica().setVisible(true);
		}
	}
	private class BtnBuscarContactoActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			getFrmAgendaMonoltica().setVisible(false);
			buscarUI = new BuscarUI();
			buscarUI.getFrmAgendaMonoltica().setVisible(true);
		}
	}
	private class BtnModificarContactoActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			getFrmAgendaMonoltica().setVisible(false);
			modificarUI = new ModificarUI();
			modificarUI.getFrmAgendaMonoltica().setVisible(true);
		}
	}
}
